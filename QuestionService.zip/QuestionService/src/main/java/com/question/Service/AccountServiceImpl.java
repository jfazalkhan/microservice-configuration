package com.question.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.question.Entity.Account;
import com.question.Repository.AccountRepository;


@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountRepository questrepoRepository;	

	@Override
	public Account add(Account quest) {
		System.out.println(2);
		return questrepoRepository.save(quest);
	}
	
	 @Override
	 public List<Account> getAllList() { // TODO Auto-generated method
	  return questrepoRepository.findAll(); }
	  
	 @Override
	 public Account get(Long id) { // TODO Auto-generated method stub
	 return questrepoRepository.findById(id).orElseThrow(()-> new
	  RuntimeException("Quiz Not found")); }
	 
}
