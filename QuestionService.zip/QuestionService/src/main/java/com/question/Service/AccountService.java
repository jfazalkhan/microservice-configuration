package com.question.Service;

import java.util.List;

import com.question.Entity.Account;

public interface AccountService {
	
    Account add(Account qst);
	
	Account get(Long id);

	List<Account> getAllList();


}
