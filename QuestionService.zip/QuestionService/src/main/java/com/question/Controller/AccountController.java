package com.question.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.question.Entity.Account;
import com.question.Service.AccountService;
import com.question.Service.AccountServiceImpl;
@RestController
@RequestMapping("/account")
public class AccountController {
	
	@Autowired
	private AccountServiceImpl acc;
	
	public AccountController(AccountServiceImpl acc) {
		super();
		this.acc = acc;
	}

	@PostMapping("/addAccount")
	public Account create(@RequestBody Account account)
	{
		System.out.println(1);
		return acc.add(account);
	}
	
	@GetMapping("/getQst")
	public List<Account> get()
	{
		return acc.getAllList();
	}
	
	@GetMapping("/{id}")
	public Account getOne(@PathVariable Long id)
	{
		return acc.get(id);
		
	}
}
