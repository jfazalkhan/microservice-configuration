package com.pfo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pfo.entity.Loan;
import com.pfo.repository.LoanRepository;

@Service
public class LoanServiceImpl implements LoanService {
	
	@Autowired
	public LoanRepository lr;
	
	@Override
	public Loan applyLoan(Loan la) {
		 
		return lr.save(la);
	}
	
	@Override
	public List<Loan> getLoan() { // TODO Auto-generated method
	  return lr.findAll();
	  
	}
	
	@Override
	 public Optional<Loan> getLoanById(int loanId) { // TODO Auto-generated method stub
	 return Optional.ofNullable(lr.findById(loanId).get());
			 
	 }		
	}
