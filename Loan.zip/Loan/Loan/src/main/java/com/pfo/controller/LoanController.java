package com.pfo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pfo.entity.Loan;
import com.pfo.service.LoanServiceImpl;



@RestController
@RequestMapping("/loan")
public class LoanController {
	
	@Autowired
	private LoanServiceImpl acc;
	
	public LoanController(LoanServiceImpl acc) {
		super();
		this.acc = acc;
	}

	@PostMapping("/addLoan")
	public Loan create(@RequestBody Loan account)
	{
		System.out.println(1);
		return acc.applyLoan(account);
	}
	
	@GetMapping("/getLoan")
	public List<Loan> get()
	{
		return acc.getLoan();
	}
	
	@GetMapping("/{id}")
	public Optional<Loan> getOne(@PathVariable int id)
	{
		return acc.getLoanById(id);
		
	}

}
