package com.pfo.service;

import java.util.List;
import java.util.Optional;

import com.pfo.entity.Loan;

public interface LoanService {
	
	public Loan applyLoan(Loan l);

	public List<Loan> getLoan();

	public Optional<Loan> getLoanById(int loanId);

}
