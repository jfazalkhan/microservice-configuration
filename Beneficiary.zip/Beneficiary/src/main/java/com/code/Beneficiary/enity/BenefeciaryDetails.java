package com.code.Beneficiary.enity;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@Entity
@Table(name="BeneficiaryDetails")
public class BenefeciaryDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long bId;
	private String beneficieryName;
	private String bAddress;
	private String accountType;
	private String emailId;
	
	public BenefeciaryDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public BenefeciaryDetails(Long bId, String beneficieryName, String bAddress, String accountType,
			String emailId) {
		super();
		this.bId = bId;
		this.beneficieryName = beneficieryName;
		this.bAddress = bAddress;
		this.accountType = accountType;
		this.emailId = emailId;
	}
	
	public Long getbId() {
		return bId;
	}
	public void setbId(Long bId) {
		this.bId = bId;
	}
	public String getBeneficieryName() {
		return beneficieryName;
	}
	public void setBeneficieryName(String beneficieryName) {
		this.beneficieryName = beneficieryName;
	}
	public String getbAddress() {
		return bAddress;
	}
	public void setbAddress(String bAddress) {
		this.bAddress = bAddress;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	@Override
	public String toString() {
		return "BenefeciaryDetails [bId=" + bId + ", beneficieryName=" + beneficieryName + ", bAddress="
				+ bAddress + ", accountType=" + accountType + ", emailId=" + emailId + "]";
	}
	
	

}
