package com.code.Beneficiary.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.code.Beneficiary.aservice.AccountService;
import com.code.Beneficiary.enity.BenefeciaryDetails;
import com.code.Beneficiary.repository.BeneficiaryRepository;


@Service
public class BeneficiaryService {
	@Autowired
	private BeneficiaryRepository benrepo;
	
	@Autowired
	private AccountService accService;

	

	public BeneficiaryService(BeneficiaryRepository benrepo, AccountService accService) {
		super();
		this.benrepo = benrepo;
		this.accService = accService;
	}

	public Optional<BenefeciaryDetails findUserById(Long userId) {
		System.out.println(22);
		return benrepo.findById(userId).get();
	}

	public List<BenefeciaryDetails> getAllBenfiters() {
		List<BenefeciaryDetails> busers = benrepo.findAll();
		
		 return busers;
	}
	
	public List<AccountType> getBenefitAccount() {
		// TODO Auto-generated method stub
		System.out.println("33");
		List<AccountType> users = accService.getAllAccounts();
		
		 return users;
	}


}
