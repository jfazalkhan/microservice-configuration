package com.code.Beneficiary.aservice;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.code.Beneficiary.AccountDTO.*;

@FeignClient(value = "ACCOUNT", url = "http://localhost:8008")
public interface AccountService {
	
	@GetMapping("/accounts/getAllAccount")
	public List<AccountType> getAllAccounts();

}
