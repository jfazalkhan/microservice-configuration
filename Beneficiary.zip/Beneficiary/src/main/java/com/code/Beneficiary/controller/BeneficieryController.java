package com.code.Beneficiary.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.code.Beneficiary.AccountDTO.AccountType;
import com.code.Beneficiary.aservice.AccountService;
import com.code.Beneficiary.enity.BenefeciaryDetails;
import com.code.Beneficiary.service.BeneficiaryService;


@RestController
@RequestMapping("/beneficary")
public class BeneficieryController {
	
	@Autowired
	private BeneficiaryService benService;
	
	
	@PostMapping("/addBenfi")
	private BenefeciaryDetails saveUser(@RequestBody BenefeciaryDetails bfd)
	{
		   System.out.println(1);
		  return benService.save(bfd);
	}
	
	@GetMapping("/{id}")
	private BenefeciaryDetails findUsersById(@PathVariable("id") Long bId)
	{
		System.out.println(2);
		return benService.findUserById(bId);
	}
	 
	@GetMapping("/getAllBenfi")
    public java.util.List<BenefeciaryDetails> getAllBenefecieries() {
		System.out.println(3);
        return benService.getAllBenfiters();
    }
  
	//@CircuitBreaker(name = "CircuitBreakerService", fallbackMethod = "failedToCallMethod")
	@GetMapping("/getbenAccount")
	public List<AccountType> getAllAccountDetail()
	{
		return benService.getBenefitAccount(); 
	}
	
//	public List<AccountType> failedToCallMethod(Exception e)
//	{
//		List<AccountType> act = new ArrayList<>();
//		AccountType type = new AccountType();
//		type.setAccountId(102222L);
//		type.setAccountType("Saving");
//		type.setBranchName("BTM");
//		type.setAccountHolderName("Kumar Ravi");
//		
//		AccountType type2 = new AccountType();
//		
//		type2.setAccountId(102223L);
//		type2.setAccountType("Saving");
//		type2.setBranchName("BTM");
//		type2.setAccountHolderName("Kumar Ravi");
//		
//		act.add(type);
//		act.add(type2);
//	
//		System.out.println(e.getMessage());
//		
//		return act;
//	}
	
}
